import React from 'react';
import { Testimonial } from '../types';

const StarIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={`w-5 h-5 ${className}`}>
    <path fillRule="evenodd" d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.006 5.404.434c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354l-4.592 2.855c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.434 2.082-5.005Z" clipRule="evenodd" />
  </svg>
);


const placeholderTestimonials: Testimonial[] = [
  {
    id: 't1',
    quote: 'أفضل سمن بلدي ذقته في حياتي! الطعم غني والجودة ممتازة. العرض كان رائعًا أيضًا!',
    author: 'فاطمة أحمد',
    location: 'القاهرة',
  },
  {
    id: 't2',
    quote: 'الزبدة طازجة ولذيذة جدًا، تذكرني بزبدة جدتي. سأطلب مرة أخرى بالتأكيد.',
    author: 'محمد علي',
    location: 'الإسكندرية',
  },
  {
    id: 't3',
    quote: 'جودة لا تُقارن وسعر مناسب. العرض المجاني كان مفاجأة سارة. شكرًا لكم!',
    author: 'سارة إبراهيم',
    location: 'الجيزة',
  },
];

export const Testimonials: React.FC = () => {
  return (
    <section className="py-16 md:py-24 bg-yellow-100"> {/* Warmer section background */}
      <div className="container mx-auto px-6">
        <h2 className="text-3xl md:text-4xl font-bold text-center text-yellow-800 mb-12"> {/* Warmer heading */}
          ماذا يقول عملاؤنا عنا؟
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {placeholderTestimonials.map((testimonial) => (
            <div key={testimonial.id} className="bg-stone-50 p-8 rounded-xl shadow-lg"> {/* Off-white card background */}
              <div className="flex mb-3">
                {[...Array(5)].map((_, i) => <StarIcon key={i} className="text-yellow-400" />)} {/* Stars remain yellow */}
              </div>
              <p className="text-yellow-700 italic mb-4 leading-relaxed">"{testimonial.quote}"</p> {/* Warmer quote text */}
              <p className="font-bold text-yellow-800">{testimonial.author}</p> {/* Warmer author text */}
              {testimonial.location && <p className="text-sm text-gray-500">{testimonial.location}</p>}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};