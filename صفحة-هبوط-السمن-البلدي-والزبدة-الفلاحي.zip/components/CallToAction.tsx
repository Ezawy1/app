import React from 'react';

export const CallToAction: React.FC = () => {

  const handleScrollTo = (event: React.MouseEvent<HTMLAnchorElement>, targetId: string) => {
    event.preventDefault();
    const targetElement = document.getElementById(targetId.substring(1)); // Remove '#'
    if (targetElement) {
      targetElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="py-16 md:py-24 bg-yellow-600 text-stone-50"> {/* Deeper gold background, warm white text */}
      <div className="container mx-auto px-6 text-center">
        <h2 className="text-3xl md:text-4xl font-extrabold mb-6">
          هل أنت مستعد لتذوق الجودة الأصيلة؟
        </h2>
        <p className="text-xl md:text-2xl mb-10 max-w-2xl mx-auto">
          لا تفوت عرضنا المتكامل! اطلب الآن واستمتع بأفضل سمن بلدي، زبدة فلاحي، وقشطة طازجة تصلك حتى باب منزلك.
        </p>
        <a
          href="#order-form"
          onClick={(e) => handleScrollTo(e, "#order-form")}
          className="bg-yellow-800 hover:bg-yellow-900 text-white font-bold py-4 px-12 rounded-lg text-lg transition duration-300 ease-in-out transform hover:scale-105 shadow-xl" // Dark earthy brown button
        >
          اطلب الآن واستفد من العرض الذهبي!
        </a>
      </div>
    </section>
  );
};