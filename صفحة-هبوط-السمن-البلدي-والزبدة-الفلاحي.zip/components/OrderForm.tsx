
import React, { useState, useEffect } from 'react';
import { Offer } from '../types';

interface OrderFormProps {
  offers: Offer[];
}

// !!!!! IMPORTANT !!!!!
// This URL should be your actual Google Apps Script Web App URL
const GOOGLE_APPS_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbxhcqw1kVHII8dVVWRhUFBvLcnCmU9nVo7FziB7n0qQBEiL_dpQ9OmK8QU-vLdS6xLC7g/exec';

export const OrderForm: React.FC<OrderFormProps> = ({ offers }) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [selectedOfferId, setSelectedOfferId] = useState<string | null>(null);
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submissionStatus, setSubmissionStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [submissionMessage, setSubmissionMessage] = useState('');


  useEffect(() => {
    if (typeof window !== 'undefined') {
      const preSelectedOfferId = localStorage.getItem('selectedOfferId');
      if (preSelectedOfferId && offers.find(o => o.id === preSelectedOfferId)) {
        setSelectedOfferId(preSelectedOfferId);
      } else if (offers.length > 0) {
        const primaryOffer = offers.find(o => o.isPrimary);
        setSelectedOfferId(primaryOffer ? primaryOffer.id : offers[0].id);
      }
      localStorage.removeItem('selectedOfferId');
    }
  }, [offers]);


  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSubmissionMessage('');
    setSubmissionStatus('idle');

    if (!selectedOfferId) {
      setSubmissionMessage('يرجى اختيار أحد العروض المتاحة.');
      setSubmissionStatus('error');
      return;
    }

    if (!name.trim() || !phone.trim() || !address.trim()) {
      setSubmissionMessage('يرجى ملء جميع الحقول المطلوبة: الاسم، رقم الهاتف، والعنوان.');
      setSubmissionStatus('error');
      return;
    }

    const phoneRegex = /^01[0-2,5]{1}[0-9]{8}$/;
    if (!phoneRegex.test(phone)) {
      setSubmissionMessage('يرجى إدخال رقم هاتف مصري صحيح (مثال: 01xxxxxxxxx).');
      setSubmissionStatus('error');
      return;
    }

    setIsSubmitting(true);
    const selectedOfferDetails = offers.find(o => o.id === selectedOfferId);

    const formData = {
      timestamp: new Date().toISOString(),
      selectedOfferId: selectedOfferId,
      offerTitle: selectedOfferDetails?.title || 'N/A',
      name: name,
      phone: phone,
      address: address,
    };

    try {
      await fetch(GOOGLE_APPS_SCRIPT_URL, {
        method: 'POST',
        mode: 'no-cors', // Changed from 'cors'
        body: JSON.stringify(formData),
        headers: {
          // For 'no-cors', Content-Type 'application/json' might be handled as 'text/plain' by the browser.
          // The Apps Script should be prepared to parse e.postData.contents as a JSON string.
          'Content-Type': 'application/json',
        },
      });
      
      // For 'no-cors' mode, we cannot access the response.
      // If fetch doesn't throw an error, we assume the request was sent.
      setSubmissionStatus('success');
      setSubmissionMessage('تم استلام طلبك بنجاح! سنتواصل معك قريباً.');
      // Optionally reset form fields if desired:
      // setName('');
      // setPhone('');
      // setAddress('');
      // if (offers.length > 0) {
      //   const primaryOffer = offers.find(o => o.isPrimary);
      //   setSelectedOfferId(primaryOffer ? primaryOffer.id : offers[0].id);
      // }

    } catch (error) { // Network error or other issue preventing the request itself
      console.error('Network error or other issue submitting to Google Apps Script (no-cors mode):', error);
      setSubmissionStatus('error');
      let userErrorMessage = 'فشل إرسال الطلب. ';
      if (error instanceof TypeError && typeof error.message === 'string' && error.message.toLowerCase().includes('failed to fetch')) {
        userErrorMessage += 'قد يرجع ذلك إلى مشكلة في الاتصال بالشبكة أو أن عنوان URL للخدمة غير صحيح. يرجى التحقق من اتصالك بالإنترنت والمحاولة مرة أخرى.';
      } else if (error instanceof Error) {
        userErrorMessage += `حدث خطأ فني: ${error.message}.`;
      } else {
        userErrorMessage += 'حدث خطأ غير متوقع.';
      }
      userErrorMessage += ' حاول مرة أخرى أو تواصل مع الدعم إذا استمرت المشكلة.';
      setSubmissionMessage(userErrorMessage);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (submissionStatus === 'success') {
    const submittedOffer = offers.find(o => o.id === selectedOfferId);
    return (
      <section id="order-form" className="py-16 md:py-24 bg-green-50">
        <div className="container mx-auto px-6 text-center">
            <div className="bg-white p-8 md:p-12 rounded-xl shadow-xl max-w-lg mx-auto border-t-4 border-green-600">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-green-500 mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <h3 className="text-2xl md:text-3xl font-semibold text-green-700 mb-3">شكراً لك! 🙏</h3>
              <p className="text-gray-700 text-lg leading-relaxed">
                {submissionMessage || `تم استلام طلبك بنجاح بخصوص ${submittedOffer?.title || 'العرض المختار'}. سنتواصل معك قريباً لتأكيد التفاصيل وموعد التوصيل.`}
              </p>
              <p className="text-gray-600 mt-4 text-sm">
                سيتم الشحن مجاناً والدفع عند الاستلام.
              </p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="order-form" className="py-16 md:py-24 bg-yellow-50">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl md:text-4xl font-bold text-center text-yellow-800 mb-10">
          📝 اطلب الآن واستمتع بعرض الخير!
        </h2>
        <form onSubmit={handleSubmit} className="max-w-xl mx-auto bg-stone-50 p-8 md:p-10 rounded-xl shadow-2xl space-y-6 border-t-4 border-yellow-500">
          
          {(submissionStatus === 'error' && submissionMessage) && (
            <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded-md" role="alert">
              <p className="font-bold">خطأ في الإرسال</p>
              <p>{submissionMessage}</p>
            </div>
          )}
          
          {offers.length > 0 && (
            <fieldset className="space-y-4">
              <legend className="block text-lg font-semibold text-yellow-800 mb-3">اختر العرض المناسب لك <span className="text-red-500">*</span></legend>
              {offers.map((offer) => (
                <label key={offer.id} htmlFor={`offer-${offer.id}`} className={`flex items-center p-4 border rounded-lg cursor-pointer transition-all duration-200 ${selectedOfferId === offer.id ? 'bg-amber-100 border-amber-500 ring-2 ring-amber-500' : 'border-yellow-400 hover:border-amber-500'}`}>
                  <input
                    type="radio"
                    id={`offer-${offer.id}`}
                    name="selectedOffer"
                    value={offer.id}
                    checked={selectedOfferId === offer.id}
                    onChange={() => setSelectedOfferId(offer.id)}
                    className="h-5 w-5 text-amber-600 focus:ring-amber-500 border-gray-300"
                    required
                    aria-required="true"
                  />
                  <span className="ml-3 text-yellow-800">
                    <span className="font-semibold block">{offer.title}</span>
                    <span className="text-sm text-green-600 block">{offer.price}</span>
                    <span className="text-xs text-gray-500 block">{offer.items.join('، ')}</span>
                  </span>
                </label>
              ))}
            </fieldset>
          )}

          <div>
            <label htmlFor="name" className="block text-lg font-semibold text-yellow-800 mb-2">الاسم الكامل <span className="text-red-500">*</span></label>
            <input
              type="text"
              id="name"
              name="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              aria-required="true"
              className="w-full px-4 py-3 border border-yellow-400 rounded-lg focus:ring-2 focus:ring-yellow-600 focus:border-yellow-600 transition duration-200 text-lg text-yellow-900 placeholder-yellow-500"
              placeholder="مثال: سارة محمد"
              aria-describedby="name-help"
            />
            <p id="name-help" className="text-xs text-yellow-600 mt-1">الاسم الذي سيستخدم في الشحن والتواصل.</p>
          </div>
          <div>
            <label htmlFor="phone" className="block text-lg font-semibold text-yellow-800 mb-2">رقم الهاتف <span className="text-red-500">*</span></label>
            <input
              type="tel"
              id="phone"
              name="phone"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              required
              aria-required="true"
              className="w-full px-4 py-3 border border-yellow-400 rounded-lg focus:ring-2 focus:ring-yellow-600 focus:border-yellow-600 transition duration-200 text-lg text-yellow-900 placeholder-yellow-500"
              placeholder="مثال: 01xxxxxxxxx"
              pattern="^01[0-2,5]{1}[0-9]{8}$"
              title="يرجى إدخال رقم هاتف مصري صحيح مكون من 11 رقمًا ويبدأ بـ 01."
              aria-describedby="phone-help"
            />
             <p id="phone-help" className="text-xs text-yellow-600 mt-1">سنتواصل معك على هذا الرقم لتأكيد الطلب.</p>
          </div>
          <div>
            <label htmlFor="address" className="block text-lg font-semibold text-yellow-800 mb-2">العنوان بالتفصيل <span className="text-red-500">*</span></label>
            <textarea
              id="address"
              name="address"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              required
              aria-required="true"
              rows={4}
              className="w-full px-4 py-3 border border-yellow-400 rounded-lg focus:ring-2 focus:ring-yellow-600 focus:border-yellow-600 transition duration-200 text-lg text-yellow-900 placeholder-yellow-500"
              placeholder="مثال: 123 شارع الجمهورية، الدور الثالث، شقة 5، مدينة نصر، القاهرة"
              aria-describedby="address-help"
            />
            <p id="address-help" className="text-xs text-yellow-600 mt-1">اكتب العنوان كاملاً لضمان وصول الشحنة.</p>
          </div>
          <button
            type="submit"
            disabled={isSubmitting}
            className={`w-full text-white font-bold py-4 px-6 rounded-lg text-xl transition duration-300 ease-in-out transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 shadow-lg ${
              isSubmitting
                ? 'bg-gray-400 cursor-not-allowed'
                : 'bg-green-600 hover:bg-green-700 focus:ring-green-500'
            }`}
          >
            {isSubmitting ? 'جاري الإرسال...' : 'إرسال الطلب (الدفع عند الاستلام)'}
          </button>
          <p className="text-xs text-yellow-700 text-center mt-4">
            بالنقر على "إرسال الطلب"، فإنك توافق على <a href="#terms" className="text-green-600 hover:underline">شروط الخدمة</a> و <a href="#privacy" className="text-green-600 hover:underline">سياسة الخصوصية</a> (صفحات وهمية حالياً).
          </p>
        </form>
        <p className="mt-10 text-center text-yellow-700 max-w-2xl mx-auto text-sm md:text-base">
          نحن نهتم بخصوصيتك. سيتم استخدام بياناتك فقط لمعالجة طلبك وتوصيله. <br/>
          تذكر: الشحن مجاني لجميع المحافظات والدفع نقداً عند الاستلام.
        </p>
      </div>
    </section>
  );
};
