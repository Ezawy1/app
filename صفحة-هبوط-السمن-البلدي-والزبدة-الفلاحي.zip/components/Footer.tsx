import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-yellow-900 text-yellow-200 py-8 text-center"> {/* Dark earthy brown background, warm light text */}
      <div className="container mx-auto px-6">
        <p className="mb-2">
          جميع الحقوق محفوظة &copy; {new Date().getFullYear()} لـِ (سمن وزبدة البركة) {/* Example Brand Name */}
        </p>
        <p className="text-sm">
          سمن بلدي فاخر وزبدة فلاحي طازجة - صنع بحب في مصر
        </p>
        {/* You can add social media links or contact info here */}
        {/* <div className="mt-4">
          <a href="#" className="text-yellow-400 hover:text-yellow-300 mx-2">فيسبوك</a>
          <a href="#" className="text-yellow-400 hover:text-yellow-300 mx-2">انستجرام</a>
        </div> */}
      </div>
    </footer>
  );
};