import React from 'react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {

  const handleScrollTo = (event: React.MouseEvent<HTMLAnchorElement>, targetId: string) => {
    event.preventDefault();
    const targetElement = document.getElementById(targetId.substring(1)); // Remove '#'
    if (targetElement) {
      targetElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="bg-stone-50 rounded-xl shadow-lg overflow-hidden transform transition duration-300 hover:shadow-2xl hover:scale-105 flex flex-col"> {/* Off-white background */}
      <img 
        src={product.imageUrl} 
        alt={product.altText} 
        className="w-full h-56 object-cover"
      />
      <div className="p-6 flex flex-col flex-grow">
        <h3 className="text-2xl font-bold text-yellow-800 mb-2">{product.name}</h3> {/* Warmer heading */}
        <p className="text-yellow-700 text-sm mb-4 flex-grow">{product.description}</p> {/* Warmer description */}
        <div className="mt-auto">
          {product.originalPrice && (
            <p className="text-gray-500 line-through text-md mb-1">
              {product.originalPrice}
            </p>
          )}
          <p className="text-2xl font-extrabold text-green-600 mb-4">{product.price}</p>
          <a
            href="#order-form"
            onClick={(e) => handleScrollTo(e, "#order-form")}
            className="w-full block text-center bg-yellow-500 hover:bg-yellow-600 text-gray-900 font-semibold py-3 px-4 rounded-lg transition duration-300"
            role="button"
          >
            جزء من عرض الخير (اطلب الآن)
          </a>
        </div>
      </div>
    </div>
  );
};