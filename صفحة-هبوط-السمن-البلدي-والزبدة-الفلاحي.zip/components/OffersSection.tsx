import React from 'react';
import { Offer } from '../types';

interface OffersSectionProps {
  offers: Offer[];
}

const CheckIcon: React.FC<{className?: string}> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className={`w-5 h-5 ${className}`}>
    <path fillRule="evenodd" d="M16.704 4.153a.75.75 0 01.143 1.052l-8 10.5a.75.75 0 01-1.127.075l-4.5-4.5a.75.75 0 011.06-1.06l3.894 3.893 7.48-9.817a.75.75 0 011.05-.143z" clipRule="evenodd" />
  </svg>
);


export const OffersSection: React.FC<OffersSectionProps> = ({ offers }) => {

  const handleOrderClick = (event: React.MouseEvent<HTMLAnchorElement>, offerId: string, targetId: string) => {
    event.preventDefault(); // Prevent default anchor behavior
    if (typeof window !== 'undefined') {
       localStorage.setItem('selectedOfferId', offerId);
       const targetElement = document.getElementById(targetId.substring(1)); // Remove '#' from targetId
       if (targetElement) {
         targetElement.scrollIntoView({ behavior: 'smooth' });
       }
    }
  };

  return (
    <section id="offers-section" className="py-16 md:py-24 bg-yellow-100"> {/* Warmer section background */}
      <div className="container mx-auto px-6">
        <h2 className="text-3xl md:text-4xl font-bold text-center text-yellow-800 mb-12"> {/* Darker, warmer heading */}
          🎉 عروضنا المميزة المصممة خصيصاً لك! 🎉
        </h2>
        <div className={`grid grid-cols-1 ${offers.length > 1 ? 'lg:grid-cols-2' : ''} gap-8 md:gap-12 items-stretch`}>
          {offers.map((offer) => (
            <div 
              key={offer.id} 
              className={`relative bg-stone-50 p-8 rounded-xl shadow-2xl flex flex-col transition-all duration-300 hover:shadow-amber-300/50 overflow-hidden ${offer.isPrimary ? 'border-4 border-dashed border-yellow-500' : 'border-2 border-yellow-300'}`} // Off-white bg, warmer border
            >
              {offer.isPrimary && offer.highlightTag && (
                <div className="absolute top-0 right-0 transform translate-x-1/2 -translate-y-1/2 rotate-45">
                    <div className="bg-red-600 text-white text-xs font-bold uppercase py-1 px-8 shadow-md animate-pulse">
                         {offer.highlightTag}
                    </div>
                </div>
              )}
              <h3 className={`text-2xl font-bold mb-6 text-center ${offer.isPrimary ? 'text-yellow-700' : 'text-yellow-800'}`}> {/* Warmer heading colors */}
                {offer.title}
              </h3>
              <ul className="space-y-3 mb-6 text-yellow-700 flex-grow"> {/* Warmer text color */}
                {offer.items.map((item, index) => (
                  <li key={index} className="flex items-start">
                    <CheckIcon className="text-green-500 mr-2 mt-1 flex-shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
              {offer.savings && (
                <p className={`text-sm p-2 rounded-md text-center mb-6 ${offer.isPrimary ? "text-red-700 bg-red-100 font-semibold" : "text-yellow-800 bg-yellow-100"}`}> {/* Adjusted non-primary savings text */}
                  {offer.savings}
                </p>
              )}
              <div className="text-center mb-6">
                {offer.originalPrice && offer.isPrimary && (
                  <p className="text-xl text-gray-500 line-through"> {/* Keeping gray for strikethrough for clarity */}
                    {offer.originalPrice}
                  </p>
                )}
                <p className="text-3xl md:text-4xl font-extrabold text-green-600">
                  {offer.price}
                </p>
              </div>
              <a
                href="#order-form" // Keep href for semantics and accessibility
                onClick={(e) => handleOrderClick(e, offer.id, "#order-form")}
                className={`w-full block text-center font-bold py-3 px-8 rounded-lg text-lg transition duration-300 ease-in-out transform hover:scale-105 shadow-lg ${
                  offer.isPrimary 
                    ? 'bg-yellow-500 hover:bg-yellow-600 text-gray-900' 
                    : 'bg-green-500 hover:bg-green-600 text-white' // Standard green for secondary CTA
                }`}
              >
                {offer.ctaText || 'اطلب الآن'}
              </a>
            </div>
          ))}
        </div>
        <div className="mt-12 text-center">
            <p className="text-lg text-green-700 font-semibold">
              🚚 الشحن مجاني لجميع المحافظات!
            </p>
            <p className="text-lg text-green-700 font-semibold mt-2">
              💵 الدفع عند الاستلام متاح لجميع الطلبات!
            </p>
            <p className="mt-6 text-yellow-700"> {/* Warmer text */}
              الجودة التي تستحقها، بالسعر الذي تحبه. كل خيرات الريف في باقات متنوعة، مع شحن مجاني ودفع عند الاستلام!
            </p>
        </div>
      </div>
    </section>
  );
};