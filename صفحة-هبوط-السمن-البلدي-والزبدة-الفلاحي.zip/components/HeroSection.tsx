import React from 'react';

export const HeroSection: React.FC = () => {

  const handleScrollTo = (event: React.MouseEvent<HTMLAnchorElement>, targetId: string) => {
    event.preventDefault();
    const targetElement = document.getElementById(targetId.substring(1)); // Remove '#'
    if (targetElement) {
      targetElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section 
      className="relative bg-cover bg-center py-24 md:py-32 lg:py-48 text-white"
      // For a true "falahy" feel, replace this placeholder with an authentic image of Egyptian countryside or farm life.
      style={{ backgroundImage: "url('https://picsum.photos/seed/egyptianfarmwomancow/1600/900')" }}
    >
      <div className="absolute inset-0 bg-yellow-900 opacity-70"></div> {/* Warmer overlay */}
      <div className="container mx-auto px-6 text-center relative z-10">
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold mb-6 leading-tight drop-shadow-lg">
          عرض الخير كله! <span className="text-yellow-300">سمن بلدي</span>، <span className="text-amber-200">زبدة فلاحي</span>، و<span className="text-orange-200">قشطة طازجة</span>
        </h1>
        <p className="text-xl md:text-2xl mb-10 max-w-3xl mx-auto drop-shadow-md">
          اكتشف الطعم الحقيقي للجودة الفاخرة. نقدم لك أنقى أنواع السمن، الزبدة، والقشطة، محضرة بعناية فائقة من خير الطبيعة وبأسعار لا تُصدق.
        </p>
        <a
          href="#offers-section" 
          onClick={(e) => handleScrollTo(e, "#offers-section")}
          className="bg-yellow-500 hover:bg-yellow-600 text-gray-900 font-bold py-4 px-10 rounded-lg text-lg transition duration-300 ease-in-out transform hover:scale-105 shadow-xl"
        >
          اكتشف عروضنا الحصرية!
        </a>
      </div>
    </section>
  );
};