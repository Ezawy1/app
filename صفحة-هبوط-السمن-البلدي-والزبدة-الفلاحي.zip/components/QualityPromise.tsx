import React from 'react';

const CheckCircleIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={`w-10 h-10 ${className}`}>
    <path fillRule="evenodd" d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12Zm13.36-1.814a.75.75 0 1 0-1.22-.872l-3.236 4.53L9.53 12.22a.75.75 0 0 0-1.06 1.06l2.25 2.25a.75.75 0 0 0 1.14-.094l3.75-5.25Z" clipRule="evenodd" />
  </svg>
);

const ShippingIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={`w-10 h-10 ${className}`}>
    <path d="M3.375 4.5C2.339 4.5 1.5 5.34 1.5 6.375V13.5h12V6.375c0-1.036-.84-1.875-1.875-1.875h-8.25ZM13.5 15h-12v2.625c0 1.035.84 1.875 1.875 1.875h.375a3 3 0 1 1-1.125 0H2.25A2.625 2.625 0 0 1 0 17.625V6.375C0 4.585 1.085 3 2.813 3H12.187c1.728 0 2.813 1.585 2.813 3.375V15h1.938A2.625 2.625 0 0 1 20.25 17.625v.375a3 3 0 1 1-1.5 0h.375a1.875 1.875 0 0 0 1.875-1.875V15h-6V4.875C15 3.839 14.16 3 13.125 3H4.875C3.839 3 3 3.84 3 4.875V15H1.5v-2.625A2.625 2.625 0 0 1 4.125 10h5.25V4.5H3.375Z" />
    <path d="M8.25 19.5a1.5 1.5 0 1 0-3 0 1.5 1.5 0 0 0 3 0ZM15.75 19.5a1.5 1.5 0 1 0-3 0 1.5 1.5 0 0 0 3 0Z" />
 </svg>
);


const PaymentIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={`w-10 h-10 ${className}`}>
    <path d="M1.5 4.5a3 3 0 0 1 3-3h15a3 3 0 0 1 3 3v15a3 3 0 0 1-3 3h-15a3 3 0 0 1-3-3v-15Zm3-1.5a1.5 1.5 0 0 0-1.5 1.5v4.5h18V4.5a1.5 1.5 0 0 0-1.5-1.5h-15ZM21 10.5H3v9A1.5 1.5 0 0 0 4.5 21h15a1.5 1.5 0 0 0 1.5-1.5v-9Z" />
    <path d="M15.75 14.25a.75.75 0 0 1 .75-.75h1.5a.75.75 0 0 1 .75.75v1.5a.75.75 0 0 1-.75.75h-1.5a.75.75 0 0 1-.75-.75v-1.5Z" />
  </svg>
);


interface PromiseItemProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const PromiseItem: React.FC<PromiseItemProps> = ({ icon, title, description }) => (
  <div className="flex flex-col items-center text-center p-6 bg-yellow-50 rounded-xl shadow-lg transition-all duration-300 hover:shadow-xl hover:scale-105"> {/* Warmer item background */}
    <div className="text-yellow-700 mb-4"> {/* Warmer icon color */}
      {icon}
    </div>
    <h3 className="text-xl font-semibold text-yellow-800 mb-2">{title}</h3> {/* Warmer title */}
    <p className="text-yellow-700 text-sm leading-relaxed">{description}</p> {/* Warmer description */}
  </div>
);

export const QualityPromise: React.FC = () => {
  const promises = [
    {
      id: 'quality',
      icon: <CheckCircleIcon />,
      title: 'جودة مضمونة 100%',
      description: 'نستخدم أجود المكونات الطبيعية ونتبع الطرق التقليدية الأصيلة لضمان منتج فاخر وصحي.',
    },
    {
      id: 'shipping',
      icon: <ShippingIcon />,
      title: 'شحن مجاني وسريع',
      description: 'نصلك أينما كنت في جميع محافظات مصر مع خدمة شحن مجانية وسريعة حتى باب منزلك.',
    },
    {
      id: 'payment',
      icon: <PaymentIcon />,
      title: 'الدفع عند الاستلام',
      description: 'نوفر لك راحة البال مع خيار الدفع نقدًا عند استلام طلبك والتأكد من جودته بنفسك.',
    },
  ];

  return (
    <section className="py-16 md:py-24 bg-stone-100"> {/* Light off-white section background */}
      <div className="container mx-auto px-6">
        <h2 className="text-3xl md:text-4xl font-bold text-center text-yellow-900 mb-12 md:mb-16"> {/* Darker, warmer heading */}
          التزامنا تجاهك: الجودة والراحة
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-10">
          {promises.map((promise) => (
            <PromiseItem
              key={promise.id}
              icon={promise.icon}
              title={promise.title}
              description={promise.description}
            />
          ))}
        </div>
      </div>
    </section>
  );
};